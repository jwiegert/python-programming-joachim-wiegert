import geometry as geo

triangle1_area = geo.triangle_area(3,5)
print(triangle1_area)

print(geo.square_area(10))