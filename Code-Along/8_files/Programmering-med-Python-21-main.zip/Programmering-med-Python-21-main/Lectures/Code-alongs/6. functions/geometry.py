def triangle_area(base, height): 
    return base*height/2

def triangle_circumference(side1, side2, side3):
    return sum([side1, side2, side3])

def square_area(side):
    return side**2

def square_circumference(side):
    return side*4