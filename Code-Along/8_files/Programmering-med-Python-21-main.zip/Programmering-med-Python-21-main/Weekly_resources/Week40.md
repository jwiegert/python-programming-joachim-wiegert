# Week 40 Resource

[Back to main page :house:](https://github.com/kokchun/Programmering-med-Python-21)

## under construction

## Video guides :video_camera:

## Theory :book:

## Lecture notes :mortar_board:

## Exercises :running: