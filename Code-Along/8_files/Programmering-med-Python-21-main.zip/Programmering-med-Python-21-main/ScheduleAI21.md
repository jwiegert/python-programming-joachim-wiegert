# Schema - Programmering med Python (AI21)

| Vecka |          Måndag          |     Tisdag (distans)     |          Torsdag          |    Deadlines    |
| :---: | :----------------------: | :----------------------: | :-----------------------: | :-------------: |
|  34   |        13:15-16 F        | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br> 13:15-16 S | Labb 1 (fredag) |
|  35   |                          | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S  |                 |
|  36   | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S  |                 |
|  37   | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S |  9-11:45 F<br>13:15-16 S  | Labb 2 (fredag) |
|  38   | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S |  9-11:45 F<br>13:15-16 S  |                 |
|  39   | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S  | Labb 3 (fredag) |
|  40   | 9-11:45 F <br>13:15-16 S | 9-11:45 F <br>13:15-16 S |  9-11:45 F<br>13:15-16 S  |                 |
|  41   | 9-11:45 S <br>13:15-16 S | 9-11:45 S <br>13:15-16 S |      **Tenta** 9-12       |                 |

F - föreläsning

S - stuga

[Back to main page :house:](https://github.com/kokchun/Programmering-med-Python-21)